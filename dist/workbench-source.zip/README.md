# MML Workbench

可自行修改的瑪奇 Mobile 六軌 MML 檢查與預覽工作台。網站核心 v0.1.0，工具服務 v0.3.0。

> Studio v1 的來源、Published Canonical v1 文件與測試會與既有 Workbench 並存；**把 Studio 原始碼納入 `main` 不會自動切換正式 Railway/MCP 部署**。目前 production Railway/MCP 仍使用既有 Workbench 路徑。舊版工作基準凍結於 `legacy-v0.2.0`。唯一規則載入入口是 [docs/CANONICAL_MANIFEST.md](docs/CANONICAL_MANIFEST.md)，再依其快照與 authority map 載入 Published Canonical；本 README、Workbench 與舊 Skill 均不是規則權威。

Studio／repository Skill 共用 Manifest Bootstrap。更新本機 `origin/main` 後，執行 `npm run canonical:bootstrap` 取得 Manifest、固定快照文件與 Git 身份；只有要核對身份時才使用 `-- --summary`。載入失敗回報 `CANONICAL_NOT_LOADED`，不得退回舊 Skill／Master／patch。操作方式見 [studio/README.md](studio/README.md)。

## 獨立主機部署

`railway/` 提供獨立的 Node HTTP 服務、單一擁有者 OAuth、Dockerfile 與部署說明；它沿用原有 MML 核心。此版本採用 OAuth DCR、公用客戶端與 PKCE S256，授權資料保存於獨立 SQLite volume，MML 不入庫。請依 `railway/README.md` 完成環境變數、持久磁碟及來源連接。

私人 GitHub 程式庫為 `a91453/mml-tools`；Railway 精確目標與進度記錄於 `railway/deployment-target.json`。部署使用 Railway 服務設定及 `railway/Dockerfile`，不使用新服務已停用的 `railway.toml` 設定方式；`railway/service-settings.json` 保存不含密碼的設定參考。本機 `npm test` 全數通過（撰寫時 1343 項），包括經由實際本機 HTTP 的 OAuth＋MCP 呼叫；本機測試、正式 HTTPS 檢查及使用者在 ChatGPT 的連接驗收分開記錄。

Railway 已於 2026-09-08 22:48 UTC 完成部署，GitHub 來源為 `a91453/mml-tools` 的 `main`。已觀察到 `/healthz` 200、OAuth metadata 200、未登入 `/mcp` 401；完整使用者 OAuth 與授權後工具呼叫仍需另外驗收。正式工具網址為 `https://mml-tools-production.up.railway.app/mcp`，採 OAuth DCR。較早的「Application not found」是歷史部署狀態，不是目前的登入錯誤原因。

登入頁修正：只將 HTML 的 `Referrer-Policy` 設為 `same-origin`，避免一般表單送出被 `no-referrer` 轉成 `Origin: null`；保留嚴格來源、CSRF、密碼及 PKCE 檢查。2026-09-08 23:18 UTC 的正式 HTTPS 檢查確認此政策已生效，同來源請求通過來源及 CSRF 檢查、`null` 來源仍拒絕。之後正式紀錄出現兩次登入成功回傳 302，接著重送 403，但尚無 token 交換；這不等於 ChatGPT 連接完成。

本版另修正登入後回呼相容性：CSP 只開放本站與所選已註冊回呼來源，成功登入使用 303 返回 ChatGPT；已完成／逾時的瀏覽器表單改顯示重新連線說明，API 仍維持 JSON 拒絕。請只使用一個新開的登入頁，不要重送舊頁。Railway 已觀察到 `/data` 的 500 MB 持久磁碟；跨部署註冊保存與本人登入仍須依正式檢查結果確認。

2026-09-09 06:32 UTC 已確認回呼修正版部署成功，正式 HTTPS 回傳正確的 CSP、來源政策及失效表單說明，更新前註冊的合成客戶端也在更新後保留。此檢查沒有提交擁有者密碼；本人返回 ChatGPT、token 交換與授權工具呼叫仍待驗收。

## MCP 工具服務

新增 `POST /mcp`，使用無狀態 Streamable HTTP：

- `mml_service_info`：版本、能力與限制。
- `mml_validate`：完整六軌技術檢查、字數、Tempo Map、拍長、小節及全部 15 對重疊摘要。
- `mml_overlap_details`：同音重疊與低中音小二度／大七度區間，完整計數並可分頁取得明細。

這三個工具均唯讀，不改寫歌曲、不自動下載、不呼叫模型 API。呼叫檢查時，需明確提供 `mml` 與來源確認的 `meter_text`；例如 `0 4/4`，不能在來源未知時假設拍號。工具只處理本次傳入的資料，不會自動讀取其他對話、網站編輯器或使用者音檔。程式不保存或記錄工具傳入的歌曲；平台自身的資料政策仍適用。

`technical_ok` 和技術 PASS 不代表來源比對、聽驗、播放器回讀或遊戲驗收完成。MCP 沒有音訊播放與 MIDI／ABC 匯出工具；現有瀏覽器工作台仍提供這些功能。

### Studio Agent Interface

Agent Control Plane（Railway 專案 `mml-tools-allen`／服務 `mml-tools`）在通過 OAuth 後另外提供十二個 `studio_*` 工具與 `/api/v1/*` HTTP 介面，讓 ChatGPT、Claude、Codex、未來模型或本地 agent 透過同一套介面操作既有 Studio：專案、素材、來源匯入、編排建議、明確接受的決定、候選審查與 Final 產出。上述三個原有工具維持不變；未接上 Application Service 的 Sites Worker 仍只提供那三個。

**這不是 Studio Web 部署。** 目前 Railway 上有兩個各自獨立的平面：

| | Permanent Studio Web 平面 | Agent Control Plane |
| --- | --- | --- |
| Railway 專案 | `mml-tools-studio-permanent` | `mml-tools-allen` |
| 服務 | `studio-web-permanent` | `mml-tools` |
| 提供 | Studio PWA | OAuth、`/mcp`、`/api/v1/*` |
| 發布方式 | 釘選的已驗證 release artifact＋trust bundle，SHA256 驗證後原子發布 | 由本程式庫建置的容器映像 |
| Volume | `/studio-cache`（release 位元組） | `/data`（專案／素材／產出／工作紀錄） |

Permanent Studio Web 的釘選發布與驗證機制記錄於 [ops/permanent/](ops/permanent/MIGRATION_RESULT.md)，本介面不取代、不遷移、不繞過它。Studio Web **目前不使用** Application Service：它在瀏覽器中直接呼叫同一套 `studio/backend/**` 引擎。未來若要遷移，屬於後續工作。`/studio-cache` 與 `/data` 責任不可互換。

業務邏輯只有一份，位於 `studio/backend/application/`；HTTP 與 MCP 都只是 adapter，不重寫 Canonical、編排或 Final 邏輯，也不夾帶任何模型供應商相依。MCP 不承載檔案位元組：素材一律經 HTTP 上傳取得 `asset_id`。技術 PASS 不代表 source／audio／player／Mobile adaptation／實機驗收通過，`in_game` 無法由本服務設定。

介面契約、資產與工作生命週期、Canonical provenance、成本模型、安全邊界與已知限制見 [docs/STUDIO_AGENT_INTERFACE.md](docs/STUDIO_AGENT_INTERFACE.md)（實作筆記，非規則權威）。

Sites 版本依賴 Sites 的私人存取閘道。Worker 僅在閘道提供可信身分標頭後接受 MCP 呼叫；不可將 Worker 直接放到會接受任意身分標頭的公開主機。Railway 版本則使用 `railway/server.mjs` 與自己的 OAuth，不信任 Sites 身分標頭。兩者的正式 MCP URL 與 OAuth resource 不可混用；本機路由測試不能證明使用者 OAuth 連接已完成。

傳輸支援 2025-03-26、2025-06-18、2025-11-25 協定版本的此服務所需子集：initialize、ping、tools/list、tools/call、初始化與取消通知。不宣告資源、提示詞、工作排程、通知串流或工作階段能力。GET /mcp 回應 405 是預期行為；需 POST 才能進行協定測試。

## 使用

1. 貼上 `MML@...,...,...,...,...,...;`，或開啟 TXT/MML。
2. 依來源確認拍號圖、弱起及末小節，按「檢查並載入」。
3. 選 Melody、單人前三軌或完整六軌試聽。
4. 可加入本機原曲音檔，設定第0拍對應的音檔秒數，切換原曲與MML。
5. 匯出 MML、Preview MIDI、完整ABC、驗證回讀JSON或專案JSON。

沒有外部JavaScript、音色CDN或執行期套件依賴。以原生Web Audio提供程序合成音色；這不是Mabinogi Mobile音色模擬。網頁及音檔由瀏覽器處理，不上傳原曲。專案JSON保存MML與設定，音檔另行保留；本版不做背景自動保存。

## 可溯源驗證

- `core.js`：BigInt有理數MML解析、舊 Workbench strict profile、拍號與小節、完整15對重疊區間、MIDI/ABC編碼與各自解碼、逐事件及控制資料比對。
- `player.js`：從實際MIDI bytes解碼後持有自己的引擎資料；回讀匯出真正載入的資料及播放排程，保留session/hash/範圍。不会把來源預期值寫回去修成一致。
- `app.js`：完整字串、原曲A/B、依版本失效的檢查結果、匯出與載入。
- `tests/`：歷史事故反例；含錯誤音量、Program、拍號、事件、rest-tie、Nxx及混合拍號等。

新 Studio 並未修改既有安裝版 `mabinogi-mobile-mml` 技能或 production Railway/MCP；它是一套額外的來源／仲裁／驗證架構。

## 驗收範圍

`PASS` 僅屬於具名檢查。播放器回讀檢查的是載入引擎與排程，音訊context尚未啟動會明載 `not_started`。回讀不是硬體輸出錄音，不是Midify的widget回讀，不證明全曲已聽過，更不是Mobile實機驗收。

原曲身份、有效區間、分層聽驗及遊戲驗收不會自動變成PASS。有效時長比較由使用者輸入的已確認範圍計算；不自動使用容器長度、不裁尾湊2%。

**以下是 legacy Workbench v0.2.0 內建 strict profile 的歷史行為，不是目前 Canonical Studio 規則：**舊 parser 可直接解析的分母為1、2、3、4、6、8、12、16、24、32，並拒絕 Nxx、48/64 等。Current Canonical 規則以 `docs/MOBILE_SYNTAX.md` 為準：plain 64 可用、plain 1–64 非偏好值屬 caution、Nxx 為 opt-in-with-evidence；不要用舊 Workbench rejection 推論遊戲引擎不支援。

ABC輸出使用L:1/4、K:C、完整展開、小節線、同音tie及明確拍號變化。與第三方播放器的方言相容性仍需在該播放器實際載入後驗證；不宣稱Midify已支援本版的混合拍號。

GM Program及CC7會被保留並逐事件核對。聽感採有限的程序合成近似，沒有完整GM SoundFont。鼓音需自備有來源證據的Mobile音位→GM鼓面表；JSON中填写evidence不能自動證實其真實性。

## 修改及測試

使用Node.js 22以上：

```sh
npm run test:legacy   # 只跑舊 Workbench regression
npm test              # legacy + Studio symbolic regression
```

網站原始頁面放於 `dist/`。以任一支援 ES Modules 的本機 HTTP 服務開啟；不要直接以 file:// 開啟。Web Audio 需使用者點擊播放及可用音訊 context。

既有 production 部署建置仍執行 `node scripts/build.mjs`，需要 Node.js 22 以上和 `zip`；它不會因 Studio source 進入 repo 就自動切換到 Studio。Studio Node 測試另需安裝 `package.json` 中的依賴，audio-worker 則使用 `studio/audio-worker/requirements.txt`。

測試包含合成曲譜、MCP 握手與工具結果、參數和容量限制，以及缺少閘道身分時的拒絕處理。以合成身分標頭測試 Worker 僅驗證本機路由邏輯，不能當成正式 OAuth 或端到端連線驗證。

既有測試使用合成音符及假的AudioContext驗證排程契約，未執行瀏覽器UI或真實音訊硬體驗收。手機／iPad首次播放、音訊中斷恢復、長曲與實際音色需使用者試聽後繼續校正。

原始碼下載包不包含任何使用者歌曲、音檔、登入資料或部署憑證。原始碼、事件格式與測試都可帶走；Sites上的原始碼亦已版本化。
