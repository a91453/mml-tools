const CACHE = 'mml-studio-v1-c76deb21ba7848c261d6c1f7100e95fe4ac7874c3b4e4f6f05c61b04c1b8a05f';
const ASSETS = ["./","./apple-touch-icon.png","./dist/core.js","./icon.svg","./index.html","./manifest.webmanifest","./studio/backend/adaptation/index.mjs","./studio/backend/arbitration/core3-completeness.mjs","./studio/backend/arbitration/core3.mjs","./studio/backend/arbitration/harmony.mjs","./studio/backend/arbitration/lead-demotion.mjs","./studio/backend/arrangement/decision-application.mjs","./studio/backend/arrangement/decision-review.mjs","./studio/backend/arrangement/index.mjs","./studio/backend/arrangement/merge-diagnostics.mjs","./studio/backend/arrangement/role-candidates.mjs","./studio/backend/arrangement/voice-split.mjs","./studio/backend/audio/index.mjs","./studio/backend/bootstrap/index.mjs","./studio/backend/canonical/index.mjs","./studio/backend/canonical/merge.mjs","./studio/backend/canonical/micro-timing.mjs","./studio/backend/canonical/release-regrid-candidate.mjs","./studio/backend/canonical/release-timing.mjs","./studio/backend/canonical/timing.mjs","./studio/backend/compare/version-drift.mjs","./studio/backend/final/delivery-evaluator.mjs","./studio/backend/final/duration-plan.mjs","./studio/backend/final/emitter-contract.mjs","./studio/backend/final/index.mjs","./studio/backend/final/micro-gap-enforcement.mjs","./studio/backend/final/mml-emitter.mjs","./studio/backend/final/readiness.mjs","./studio/backend/final/round-trip.mjs","./studio/backend/final/technical-timing-repair.mjs","./studio/backend/mml/canonicalize.mjs","./studio/backend/mml/index.mjs","./studio/backend/mml/parser.mjs","./studio/backend/reduction/index.mjs","./studio/backend/rules/index.mjs","./studio/backend/rules/supported-releases.mjs","./studio/backend/score/index.mjs","./studio/backend/score/musicxml.mjs","./studio/backend/source/index.mjs","./studio/backend/source/midi-file.mjs","./studio/backend/source/midi.mjs","./studio/backend/source/sha256.mjs","./studio/web/app.mjs","./studio/web/arrangement-decisions.mjs","./studio/web/audio-client.mjs","./studio/web/audio-payload.mjs","./studio/web/backup-zip.mjs","./studio/web/canonical-contract.mjs","./studio/web/canonical-package.mjs","./studio/web/engine-probe-store.mjs","./studio/web/engine-probe.mjs","./studio/web/midi-source.mjs","./studio/web/mml-highlight.mjs","./studio/web/model.mjs","./studio/web/preview/player.mjs","./studio/web/preview/readback.mjs","./studio/web/preview/schedule.mjs","./studio/web/preview/soundbank-store.mjs","./studio/web/preview/worklet-console.mjs","./studio/web/published.mjs","./studio/web/pwa-update.mjs","./studio/web/review-roll.mjs","./studio/web/roll-geometry.mjs","./studio/web/roll-model.mjs","./studio/web/service/app.mjs","./studio/web/service/client.mjs","./studio/web/service/index.html","./studio/web/service/style.css","./studio/web/source-requests.mjs","./studio/web/storage.mjs","./studio/web/task-queue.mjs","./studio/web/worker-client.mjs","./studio/web/worker.mjs","./style.css","./vendor/spessasynth/core.js","./vendor/spessasynth/lib.js","./vendor/spessasynth/processor.js","./vendor/xml.mjs","./build.json"];
// cache:'reload' bypasses the browser HTTP cache (lesson from MML 工房's sw.js).
// A plain addAll may be answered from an HTTP cache that still holds the previous
// release, which would store old modules under this release's cache name.
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS.map(path => new Request(path, { cache: 'reload' }))))));
// Never skipWaiting on install: a live review must not mix old/new Canonical
// modules. The page applies a waiting release only on an explicit user request,
// after its task queue is idle and its project is saved (studio/web/pwa-update.mjs).
self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});
self.addEventListener('activate', event => event.waitUntil((async () => {
  // Prefix-scoped cleanup: the origin may host other apps' caches.
  for (const key of await caches.keys()) if (key.startsWith('mml-studio-v1-') && key !== CACHE) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  const allowed = new Set(ASSETS.map(path => new URL(path, self.registration.scope).href));
  if (!allowed.has(url.href)) return;
  event.respondWith(caches.open(CACHE).then(cache => cache.match(event.request).then(hit => hit || fetch(event.request))));
});
