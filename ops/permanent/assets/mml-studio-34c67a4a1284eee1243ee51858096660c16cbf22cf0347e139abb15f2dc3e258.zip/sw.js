const CACHE = 'mml-studio-v1-1e78713ad6bb57aff5dd5c4ef2cf841aa01f9c550471fe9aa4f216ed51596a92';
const ASSETS = ["./","./apple-touch-icon.png","./dist/core.js","./icon.svg","./index.html","./manifest.webmanifest","./studio/backend/arbitration/core3.mjs","./studio/backend/arbitration/harmony.mjs","./studio/backend/arbitration/lead-demotion.mjs","./studio/backend/audio/index.mjs","./studio/backend/bootstrap/index.mjs","./studio/backend/canonical/index.mjs","./studio/backend/canonical/merge.mjs","./studio/backend/compare/version-drift.mjs","./studio/backend/final/readiness.mjs","./studio/backend/mml/canonicalize.mjs","./studio/backend/mml/index.mjs","./studio/backend/mml/parser.mjs","./studio/backend/rules/index.mjs","./studio/backend/score/index.mjs","./studio/backend/score/musicxml.mjs","./studio/web/app.mjs","./studio/web/audio-client.mjs","./studio/web/audio-payload.mjs","./studio/web/canonical-contract.mjs","./studio/web/canonical-package.mjs","./studio/web/model.mjs","./studio/web/published.mjs","./studio/web/storage.mjs","./studio/web/task-queue.mjs","./studio/web/worker-client.mjs","./studio/web/worker.mjs","./style.css","./vendor/xml.mjs","./build.json"];
self.addEventListener('install', event => event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS))));
// Do not skipWaiting: a live review must not mix old/new Canonical modules.
self.addEventListener('activate', event => event.waitUntil((async () => {
  for (const key of await caches.keys()) if (key.startsWith('mml-studio-v1-') && key !== CACHE) await caches.delete(key);
  await self.clients.claim();
})()));
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  if (event.request.method !== 'GET' || url.origin !== self.location.origin) return;
  const allowed = new Set(ASSETS.map(path => new URL(path, self.registration.scope).href));
  if (!allowed.has(url.href)) return;
  event.respondWith(caches.open(CACHE).then(cache => cache.match(event.request).then(hit => hit || fetch(event.request))));
});
